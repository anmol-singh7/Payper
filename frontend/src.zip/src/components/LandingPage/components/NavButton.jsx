import React from "react";
import "../LandingCss/Nav.css"

const NavButton=(props)=>{

    return (
        <div className="btn">
           {props.name}
        </div>
    )
};

export default NavButton;