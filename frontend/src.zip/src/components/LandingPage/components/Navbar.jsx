import React from 'react'
import {
    AppBar,
    Toolbar,
    Box,
    List,
    ListItem,
    Typography, 
    styled,
    ListItemButton,
    ListItemText,
} from '@mui/material';
// menu
import DrawerItem from './DrawerItem';

// rotas
import { Link } from 'react-router-dom';
import { CgProfile } from "react-icons/cg";
import styles from '../../../styles/styles';
import { useSelector } from "react-redux";


// personalizacao
const StyledToolbar = styled(Toolbar) ({
    display: 'flex',
    justifyContent: 'space-between',
});

const ListMenu = styled(List)(({ theme }) => ({
    display: 'none',
    [theme.breakpoints.up("sm")] : {
        display: "flex",
    },
}));

//rotas
const itemList = [
    {
      text: "Home",
      to: "/" 
    },
    {
      text: "About",
      to: "/about"
    },
    {
        text: "Contact",
        to: "/contact"
    }
];


const Navbar = () => {
    const { isAuthenticated, user } = useSelector((state) => state.user);
    return (
        <AppBar 
        component="nav" 
        position="sticky"
        sx={{ 
            backgroundColor: 'orange', 
        }}
        elevation={0}
        >
            <StyledToolbar>
                <Typography
                variant="h6"
                component="h2"

                >
                    Payper
                </Typography>
                <Box sx={{display: { xs: 'block', sm: 'none' } }}>
                    <DrawerItem /> 
                </Box>
                <ListMenu>
                    {itemList.map( ( item ) => {
                        const { text } = item;
                        return(
                            <ListItem key={text}>
                                <ListItemButton component={Link} to={item.to}
                                sx={{
                                    color: '#fff',
                                    "&:hover": {
                                        backgroundColor: 'transparent',
                                        color: '#1e2a5a',
                                    }
                                }}
                                >
                                    <ListItemText primary={text} />
                                </ListItemButton>
                            </ListItem>
                        )
                    })}
                    <div className={`${styles.noramlFlex}`}>
                        <div className="relative cursor-pointer mr-[15px]">
                            {isAuthenticated ? (
                                <Link to="/profile" >
                                    {/* <img
                                        src={`${user.avatar.url}`}
                                        className="w-[35px] h-[35px] rounded-full"
                                        alt="Profile Pic"
                                        height="400px" width="400"
                                        color='black'
                                    /> */}
                                    <img
                                        src={`${user?.avatar?.url}`}
                                        className="w-[175px] h-[35px] rounded-full object-cover border-[1px] border-[#FFFFFF]"
                                        
                                        alt=""
                                    />
                                </Link>
                            ) : (
                                <Link to="/login">
                                    <CgProfile size={30} color="rgb(255 255 255 / 83%)" />
                                </Link>
                            )}
                        </div>
                    </div>
                </ListMenu>
                

            </StyledToolbar>
        </AppBar>
    )
}

export default Navbar;
