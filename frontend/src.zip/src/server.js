export const server = "http://localhost:3000/api/v2";


